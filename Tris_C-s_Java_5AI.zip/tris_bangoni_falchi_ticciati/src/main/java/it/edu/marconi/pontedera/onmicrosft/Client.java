package it.edu.marconi.pontedera.onmicrosft;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

// Identico al Client2

public class Client {

    public static void main(String[] args) {
        try (
                Socket socket = new Socket("localhost", 1234);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                Scanner sc = new Scanner(System.in)
        ) {
            String start = in.readLine().replace("\"", "");
            String simbolo = start.split(";")[1];
            System.out.println("Sei il giocatore: " + simbolo);

            while (true) {
                String msg = in.readLine().replace("\"", "");

                if (msg.equals("TUO_TURNO")) {
                    try {
                        System.out.print("Riga (0-2): ");
                        int r = sc.nextInt();
                        System.out.print("Colonna (0-2): ");
                        int c = sc.nextInt();
                        out.println("\"MOSSA;" + r + ";" + c + "\"");
                    } catch (Exception e) {
                        sc.nextLine();
                        out.println("\"MOSSA;-1;-1\"");
                    }
                }
                else if (msg.startsWith("GRIGLIA")) {
                    stampaGriglia(msg);
                }
                else {
                    System.out.println(msg);
                    if (msg.equals("VITTORIA") || msg.equals("SCONFITTA") || msg.equals("PAREGGIO"))
                        break;
                }
            }

        } catch (IOException e) {
            System.err.println("Errore di connessione");
        }
    }

    private static void stampaGriglia(String msg) {
        String[] b = msg.split(";")[1].split(",");
        int k = 0;
        for (int i = 0; i < 3; i++) {
            System.out.println(" " + b[k++] + " | " + b[k++] + " | " + b[k++]);
            if (i < 2) System.out.println("-----------");
        }
    }
}