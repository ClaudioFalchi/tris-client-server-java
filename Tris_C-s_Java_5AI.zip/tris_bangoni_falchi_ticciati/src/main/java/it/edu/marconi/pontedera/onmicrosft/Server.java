package it.edu.marconi.pontedera.onmicrosft;

import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public static void main(String[] args) {
        int porta = 1234;

        try (ServerSocket serverSocket = new ServerSocket(porta)) {
            System.out.println("Server avviato sulla porta " + porta);

            while (true) {
                Socket p1 = serverSocket.accept();
                System.out.println("Giocatore 1 connesso");

                Socket p2 = serverSocket.accept();
                System.out.println("Giocatore 2 connesso");

                Game game = new Game();
                ClientHandler handler = new ClientHandler(p1, p2, game);
                new Thread(handler).start();
            }

        } catch (Exception e) {
            System.err.println("Errore server: " + e.getMessage());
        }
    }
}
