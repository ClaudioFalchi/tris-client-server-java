package it.edu.marconi.pontedera.onmicrosft;

import java.io.*;
import java.net.Socket;

public class ClientHandler implements Runnable {

    private Socket p1, p2;
    private Game game;

    public ClientHandler(Socket p1, Socket p2, Game game) {
        this.p1 = p1;
        this.p2 = p2;
        this.game = game;
    }

    public void run() {
        try (
                BufferedReader in1 = new BufferedReader(new InputStreamReader(p1.getInputStream()));
                PrintWriter out1 = new PrintWriter(p1.getOutputStream(), true);
                BufferedReader in2 = new BufferedReader(new InputStreamReader(p2.getInputStream()));
                PrintWriter out2 = new PrintWriter(p2.getOutputStream(), true)
        ) {
            out1.println("\"INIZIO;X\"");
            out2.println("\"INIZIO;O\"");

            out1.println("\"TUO_TURNO\"");
            out2.println("\"ATTENDI\"");

            while (true) {
                if (!gestisciMossa(in1, out1, out2, 'X')) break;
                if (!gestisciMossa(in2, out2, out1, 'O')) break;
            }

        } catch (IOException e) {
            System.err.println("Connessione interrotta");
        } finally {
            try { p1.close(); } catch (Exception ignored) {}
            try { p2.close(); } catch (Exception ignored) {}
        }
    }

    private boolean gestisciMossa(BufferedReader in, PrintWriter corrente, PrintWriter altro, char simbolo) {
        try {
            String msg = in.readLine();
            if (msg == null) return false;

            msg = msg.replace("\"", "");
            String[] parti = msg.split(";");
            int r = Integer.parseInt(parti[1]);
            int c = Integer.parseInt(parti[2]);

            if (!game.faiMossa(r, c, simbolo)) {
                corrente.println("\"MOSSA_NON_VALIDA\"");
                corrente.println("\"TUO_TURNO\"");
                return true;
            }

            corrente.println(game.grigliaToString());
            altro.println(game.grigliaToString());

            if (game.controllaVittoria(simbolo)) {
                corrente.println("\"VITTORIA\"");
                altro.println("\"SCONFITTA\"");
                return false;
            }

            if (game.pareggio()) {
                corrente.println("\"PAREGGIO\"");
                altro.println("\"PAREGGIO\"");
                return false;
            }

            corrente.println("\"ATTENDI\"");
            altro.println("\"TUO_TURNO\"");
            return true;

        } catch (Exception e) {
            corrente.println("\"ERRORE\"");
            return false;
        }
    }
}