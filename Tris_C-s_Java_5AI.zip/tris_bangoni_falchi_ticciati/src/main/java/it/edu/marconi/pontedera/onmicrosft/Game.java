package it.edu.marconi.pontedera.onmicrosft;

public class Game {

    private char[][] board = new char[3][3];
    private char giocatoreCorrente = 'X';

    public Game() {
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                board[i][j] = ' ';
    }

    public synchronized boolean faiMossa(int r, int c, char giocatore) {
        if (r < 0 || r > 2 || c < 0 || c > 2)
            return false;

        if (board[r][c] == ' ' && giocatore == giocatoreCorrente) {
            board[r][c] = giocatore;
            giocatoreCorrente = (giocatoreCorrente == 'X') ? 'O' : 'X';
            return true;
        }
        return false;
    }

    public synchronized boolean controllaVittoria(char g) {
        for (int i = 0; i < 3; i++) {
            if ((board[i][0] == g && board[i][1] == g && board[i][2] == g) ||
                    (board[0][i] == g && board[1][i] == g && board[2][i] == g))
                return true;
        }

        return (board[0][0] == g && board[1][1] == g && board[2][2] == g) ||
                (board[0][2] == g && board[1][1] == g && board[2][0] == g);
    }

    public synchronized boolean pareggio() {
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                if (board[i][j] == ' ')
                    return false;
        return true;
    }

    public synchronized String grigliaToString() {
        StringBuilder sb = new StringBuilder("\"GRIGLIA;\"");
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                sb.append(board[i][j]).append(",");
        return sb.toString();
    }
}